"""Unit tests for hg-prompt.

The tests require nose: pip install nose && nosetests --with-doctest -v

"""